CREATE VIEW [dbo].[vehicles_ev_sales]
AS
    SELECT * FROM [vehicles_wh].[dbo].[vehicles_ev_sales]
GO